﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace $safeprojectname$.Controllers
{
    /// <summary>
    /// Demo values controller
    /// Implements the <see cref="Microsoft.AspNetCore.Mvc.ControllerBase" />
    /// </summary>
    /// <seealso cref="Microsoft.AspNetCore.Mvc.ControllerBase" />
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {

        /// <summary>
        /// Demo of a get
        /// </summary>
        /// <returns>Returns two values, value1 and value2</returns>
        [HttpGet]
        [ProducesResponseType(typeof(string[]), StatusCodes.Status200OK)]
        public ActionResult<IEnumerable<string>> Get()
        {
            // TODO: Provide your custom implementation here
            return new string[] { "value1", "value2" };
        }


        /// <summary>
        /// Gets the specified value by id.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>The value corresponding to the id</returns>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
        public ActionResult<string> Get(int id)
        {
            // TODO: Provide your custom implementation here
            return $"value{id}";
        }


        /// <summary>
        /// Creates a value
        /// </summary>
        /// <param name="value">The value.</param>
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status501NotImplemented)] // Remove once implemented
        [ProducesResponseType(StatusCodes.Status201Created)]
        public ActionResult Post([FromBody] string value)
        {
            return StatusCode(StatusCodes.Status501NotImplemented);
        }


        /// <summary>
        /// Updates a value
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="value">The value.</param>
        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status501NotImplemented)] // Remove once implemented
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        public ActionResult Put(int id, [FromBody] string value)
        {
            // TODO: Implement
            return StatusCode(StatusCodes.Status501NotImplemented); // Remove once implemented
        }


        /// <summary>
        /// Deletes a value
        /// </summary>
        /// <param name="id">The identifier.</param>
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status501NotImplemented)] // Remove once implemented
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        public ActionResult Delete(int id)
        {
            // TODO: Implement
            return StatusCode(StatusCodes.Status501NotImplemented); // Remove once implemented
        }
    }
}
